package com.example.mygrid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class GridAdapter extends ArrayAdapter {

    public List items_list;//public for now
    int custom_layout_id;

    /*public GridAdapter(Context context, int resource, List objects)
    {
        super(context, resource, objects);
    }*/
    public GridAdapter(@NonNull Context context, int resource, @NonNull List objects) {
        super(context, resource, objects);
        items_list = objects;
        custom_layout_id = resource;
    }
    @Override public int getCount()
    {
        //return super.getCount();
        return items_list.size();
    }
    /*
    @Override
    public int getCount() {
        return items_list.size();
    }*/

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View v = convertView;
        if (v == null) {

            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(custom_layout_id, null);
        }

        // get the item using the  position param
        Plant item = (Plant) items_list.get(position);


        ImageView plantThumb = v.findViewById(R.id.imageview);
        Bitmap p = BitmapFactory.decodeByteArray(item.getBlob(), 0, item.getBlob().length); //get blob from objects arraylist
        Drawable d = new BitmapDrawable(p);
        plantThumb.setImageDrawable(d);

        TextView plantTextView = v.findViewById(R.id.textview);//for now use plant id as title
        plantTextView.setText(Integer.toString(item.getId()));//get text from objects arraylist
        return v;
    }
}
