package com.example.mygrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    protected ImageView thumbObject;
    static final int PICTURE = 1;//example: requestCode to open gallery
    protected DatabaseHelper dbHelper;
    protected GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        thumbObject = (ImageView) findViewById(R.id.thumb_id);
        thumbObject.setClickable(true);
        thumbObject.setOnClickListener(onClickThumb);

        gridView = findViewById(R.id.grid_id);
        gridView.setOnItemClickListener(onClickGrid);
        loadGridView();


        if(thumbObject.getBackground()==null) {//use background to detect empty image


            dbHelper = new DatabaseHelper(this);

            if(dbHelper.getPlantByID(1)!=null&&dbHelper.getPlantByID(1).getBlob()!=null) {//example: prevent null getdata
                byte[] blob = dbHelper.getPlantByID(1).getBlob(); //example plant at row 1
                Bitmap p = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                Drawable d = new BitmapDrawable(p);
                thumbObject.setBackground(d); //example: use this to be detected
                thumbObject.setImageDrawable(d); //example: use this for activity thumbnail
            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(), "null img", Toast.LENGTH_SHORT);
                toast.show();
            }
        }


    }//end onCreate

    protected void loadGridView(){

        //open DB here and load plant objects into plant object list
        dbHelper = new DatabaseHelper(this);
        List<Plant> plants = dbHelper.getAllPlants();

        GridAdapter gridAdapter = new GridAdapter(this,R.layout.row_data,plants);//custom grid layout adapter
        gridView.setAdapter(gridAdapter);
    }

    protected AdapterView.OnItemClickListener onClickGrid = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Toast.makeText(getApplicationContext(), "CLICKED", Toast.LENGTH_SHORT).show();

            //Plant currentPlant = (Plant) parent.getItemAtPosition(position);//create Plant object from grid item
            //intent.putExtra("plant_id", String.valueOf(currentPlant.getID())); //method in Plant should be exactly getID


        }
    };

    private ImageView.OnClickListener onClickThumb = new ImageView.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast toast = Toast.makeText(getApplicationContext(), "clicked", Toast.LENGTH_SHORT);
            toast.show();

            //send intent
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICTURE);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {//receive request code to open gallery
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICTURE&& resultCode==RESULT_OK && null !=data) {

            Uri uri = data.getData();
            String[] projection ={MediaStore.Images.Media.DATA};
            Cursor cursor=getContentResolver().query(uri,projection,null,null,null);
            cursor.moveToFirst();

            int columnIndex=cursor.getColumnIndex(projection[0]);
            String path=cursor.getString(columnIndex);
            cursor.close();

            Bitmap selectFile = BitmapFactory.decodeFile(path);
            //try this method
            //ByteArrayOutputStream blob = new ByteArrayOutputStream();
            //selectFile.compress(Bitmap.CompressFormat.PNG, 0 /* Ignored for PNGs */, blob);
            //byte[] bitmapData=blob.toByteArray();
            //end try

            Drawable d = new BitmapDrawable(selectFile);
            thumbObject.setBackground(d);//example: current activity's thumbnail background



            //To do: convert to byte[] and save to db
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            // Middle parameter is quality, but since PNG is lossless, it doesn't matter
            selectFile.compress(Bitmap.CompressFormat.PNG, 0, outputStream);
            byte[] bitmapData= outputStream.toByteArray();


            //Bitmap p = BitmapFactory.decodeByteArray(bitmapData, 0, bitmapData.length);
            //Drawable d = new BitmapDrawable(p);
            //thumbObject.setBackground(d);

            dbHelper = new DatabaseHelper(this);

            //dbHelper.insertPlant(new Plant(1,bitmapData));//example: insert into db
            //dbHelper.insertPlant(new Plant(2,bitmapData));
            dbHelper.updateImageByPlantID(1,new byte[0]);
            //dbHelper.updateImageByPlantID(1,bitmapData);


            //https://stackoverflow.com/questions/28870974/pick-image-from-gallery-and-display-in-imagae-view
            //https://stackoverflow.com/questions/10977584/how-to-store-image-in-sqlite-database-from-gallery
            //https://stackoverflow.com/questions/11790104/how-to-storebitmap-image-and-retrieve-image-from-sqlite-database-in-android


        }
    }


}