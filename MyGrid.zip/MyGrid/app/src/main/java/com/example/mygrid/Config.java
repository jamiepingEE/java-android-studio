package com.example.mygrid;

import java.sql.Blob;

public class Config {
    public final static String DATABASE_NAME = "plants-db";
    public static final int DATABASE_VERSION = 1;

    public static final String PLANT_NAME_TABLE = "plant";

    //3 columns
    public static final String COLUMN_PLANT_ID = "_id"; //number 1,2,3
    public static final String COLUMN_PIC_BLOB = "blob"; //MINICAP, INTRODUCTION TO...

}
