package com.example.mygrid;

public class Plant {

    private int id;
    private byte[] blob;

    public Plant(int id, byte[] Blob) {
        this.id = id;
        this.blob = Blob;
    }

    public int getId() {
        return id;
    }

    public byte[] getBlob() {
        return blob;
    }


}
