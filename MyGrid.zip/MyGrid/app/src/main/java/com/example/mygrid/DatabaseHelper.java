package com.example.mygrid;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;
import com.example.mygrid.Plant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final String TAG="Inside DatabaseHelper";

    //don't touch this
    public DatabaseHelper(Context context){
        super(context, Config.DATABASE_NAME,null,Config.DATABASE_VERSION );
        this.context = context; //receive context instance
        Log.d(TAG,"got context/DatabaseHelper constructor end");
    }//end DatabaseHelper constructor

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {//create table of db
        //table headers
        String CREATE_TABLE_PLANT = "CREATE TABLE " + Config.PLANT_NAME_TABLE + " (" + Config.COLUMN_PLANT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Config.COLUMN_PIC_BLOB + " BLOB)";
        Log.d(TAG,CREATE_TABLE_PLANT);
        sqLiteDatabase.execSQL(CREATE_TABLE_PLANT);
        Log.d(TAG,"db created");

    }

    public long insertPlant(Plant plant){//write to DB
        long id = -1; //initialize
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //set methods
        contentValues.put(Config.COLUMN_PLANT_ID, plant.getId());
        contentValues.put(Config.COLUMN_PIC_BLOB, plant.getBlob());

        try{//call row by ID
            id = db.insertOrThrow(Config.PLANT_NAME_TABLE, null, contentValues);
        }
        catch(SQLiteException e){//don't crash
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);
        }
        finally{//close database
            db.close();
        }
        return id; //return id in terms on long

    }// end insertAssignment (into db)


    //tested, this works
    public Plant getPlantByID(Integer _id){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets a course
            //want column equal to whatever argument will be passed for selection argument(after the =?)
            //create new string array
            //"give all courses where column course code is the value that is passed at "new String[]", or (courseCode)
            cursor = db.query(Config.PLANT_NAME_TABLE,null,Config.COLUMN_PLANT_ID + "= ?",new String[]{String.valueOf(_id)},null,null,null);
            //this will read courses from the database that meet above condition
            if(cursor!=null){
                if(cursor.moveToFirst()) {//if cursor at beginning
                    int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_PLANT_ID));
                    byte[] blob = cursor.getBlob(cursor.getColumnIndex(Config.COLUMN_PIC_BLOB));


                    return new Plant(id, blob); //return a new instance of course from configured db variables above
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null){//if cursor is also not pointing at "nowhere" in the table
                cursor.close();//close cursor
                db.close(); //close db
            }

        }//end finally
        return null;// give null for example if no such course exists
    }//end of getCourseByID

    public List<Plant> getAllPlants(){ //read id, blob
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets all courses
            cursor = db.query(Config.PLANT_NAME_TABLE,null,null,null,null,null,null);
            if(cursor!=null){//not pointing at nowhere
                if(cursor.moveToFirst()) {//if cursor at beginning
                    List<Plant> plants = new ArrayList<>();


                    do {//initialize cursors for whole db row
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_PLANT_ID));
                        byte[] blob = cursor.getBlob(cursor.getColumnIndex(Config.COLUMN_PIC_BLOB));

                        //retrieve all cursor values at row and then store
                        plants.add(new Plant(id, blob)); //add to arraylist of courses

                    } while (cursor.moveToNext());

                    return plants; //return this course setting
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null) {//if cursor is also not "nowhere"
                cursor.close();//close cursor

                db.close(); //close db
            }
        }//end finally

        return Collections.emptyList(); //return empty list if all else (or null)
    }//end of getAllPlants



    //DELETE PLANT by ID
    public Integer deletePlantByID(Integer _id){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();

        try{//if problem encountered

            //delete entire row
            if(db!=null&&db.isOpen()){
                db.delete(Config.PLANT_NAME_TABLE,Config.COLUMN_PLANT_ID + "= ?",new String[]{String.valueOf(_id)});
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(db!=null&&db.isOpen()){//if cursor is also not pointing at "nowhere" in the table
                db.close(); //close db
            }
        }//end finally
        return null;// reach end of function
    }//end of getCourseByID


    public Integer updateImageByPlantID(long _id,byte[] blob){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //set methods
        contentValues.put(Config.COLUMN_PIC_BLOB, blob);

        try{//if problem encountered

            //delete entire row
            if(db!=null&&db.isOpen()){
                db.update(Config.PLANT_NAME_TABLE,contentValues,Config.COLUMN_PLANT_ID + "= ?",new String[]{String.valueOf(_id)});
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(db!=null&&db.isOpen()){//if cursor is also not pointing at "nowhere" in the table
                db.close(); //close db
            }
        }//end finally
        return null;// reach end of function
    }//end of getCourseByID

    //don't touch this
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //alter database
    }
}//end DatabaseHelper
