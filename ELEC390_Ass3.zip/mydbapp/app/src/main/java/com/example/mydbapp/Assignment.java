package com.example.mydbapp;

public class Assignment {
    private Integer ID;
    private int c_ID;
    private String Title;
    private Integer Grade=0;

    public String toString() {//override for listview display
        //return super.toString();
        //return getID() + " " + getTitle() + "\n" + getCode();
        return getID() + " " + getTitle() + "\n" + "Assignment %Grade: " + getGrade();
    }

    public Assignment(Integer ID, int c_id, String title, Integer grade) {
        this.ID = ID;
        c_ID = c_id;
        Title = title;
        Grade = grade;
    }

    //THIS ONE for fragment
    public Assignment(int c_id, String title, Integer grade) {
        c_ID = c_id;
        Title = title;
        Grade = grade;
    }

    public Assignment(String title, Integer grade) {
        Title = title;
        Grade = grade;
    }

    //setters
    public void setID(Integer ID) {
        this.ID = ID;
    }

    public void setC_ID(int c_id) {
        c_ID = c_id;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setGrade(Integer grade) {
        Grade = grade;
    }

    //getters
    public Integer getID() {
        return ID;
    }

    public int getC_ID() {
        return c_ID;
    }

    public String getTitle() {
        return Title;
    }

    public Integer getGrade() {
        return Grade;
    }
}
