package com.example.mydbapp.DatabaseHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.mydbapp.Assignment;
import com.example.mydbapp.Course;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final String TAG="Inside DatabaseHelper";

    //don't touch this
    public DatabaseHelper(Context context){
        super(context,Config.DATABASE_NAME,null,Config.DATABASE_VERSION );
        this.context = context; //receive context instance
        Log.d(TAG,"got context/DatabaseHelper constructor end");
    }//end DatabaseHelper constructor

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {//create table of db
        //table headers
        String CREATE_TABLE_COURSE = "CREATE TABLE " + Config.COURSE_NAME_TABLE + " (" + Config.COLUMN_COURSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Config.COLUMN_COURSE_TITLE + " TEXT NOT NULL, " + Config.COLUMN_COURSE_CODE + " TEXT NOT NULL)";
        Log.d(TAG,CREATE_TABLE_COURSE);
        sqLiteDatabase.execSQL(CREATE_TABLE_COURSE);
        Log.d(TAG,"db created");

        String CREATE_TABLE_ASSN = "CREATE TABLE " + Config.ASSN_NAME_TABLE + " (" + Config.COLUMN_ASSN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Config.COLUMN_C_ID + " INTEGER, " + Config.COLUMN_ASSN_TITLE + " TEXT NOT NULL, " + Config.COLUMN_ASSN_GRADE + " INTEGER)";
        Log.d(TAG,CREATE_TABLE_ASSN);
        sqLiteDatabase.execSQL(CREATE_TABLE_ASSN);
        Log.d(TAG,"db2 created");


    }

    public long insertCourse(Course course){//write to DB, want this to be from main activity fragment
        long id = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //set methods
        contentValues.put(Config.COLUMN_COURSE_TITLE, course.getTitle()); //get title using class method into db
        contentValues.put(Config.COLUMN_COURSE_CODE, course.getCode());

        try{//call course row by ID
            id = db.insertOrThrow(Config.COURSE_NAME_TABLE, null, contentValues);
        }
        catch(SQLiteException e){//don't crash
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);
        }
        finally{//close database
            db.close();
        }
        return id;

    }// end insertCourse (into db)



    public long insertAssignment(Assignment assignment){//write to DB, want this to be from main activity fragment
        long id = -1; //initialize
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        //set methods
        contentValues.put(Config.COLUMN_C_ID, assignment.getC_ID());
        contentValues.put(Config.COLUMN_ASSN_TITLE, assignment.getTitle()); //get title using class method into db
        contentValues.put(Config.COLUMN_ASSN_GRADE, assignment.getGrade());

        try{//call row by ID
            id = db.insertOrThrow(Config.ASSN_NAME_TABLE, null, contentValues);
        }
        catch(SQLiteException e){//don't crash
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);
        }
        finally{//close database
            db.close();
        }
        return id; //return id in terms on long

    }// end insertAssignment (into db)



    //This gets the entire list of courses
    public List<Course> getAllCourses(){ //read id, title, code of course (want this for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets all courses
            cursor = db.query(Config.COURSE_NAME_TABLE,null,null,null,null,null,null);
            if(cursor!=null){//not pointing at nowhere
                if(cursor.moveToFirst()) {//if cursor at beginning
                    List<Course> courses = new ArrayList<>();


                    do {//initialize cursors for whole db row
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_COURSE_ID));
                        String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_TITLE));
                        String code = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_CODE));

                        //retrieve all cursor values at row and then store
                        courses.add(new Course(id, title, code)); //add to arraylist of courses

                    } while (cursor.moveToNext());

                    return courses; //return this course setting
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null) {//if cursor is also not "nowhere"
                cursor.close();//close cursor

                db.close(); //close db
            }
        }//end finally

        return Collections.emptyList(); //return empty list if all else (or null)
    }//end of getAllCourses




    //get whole list of assignments from DB
    public List<Assignment> getAllAssignments(){ //read id, title, code of course (want this for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets all courses
            cursor = db.query(Config.ASSN_NAME_TABLE,null,null,null,null,null,null);
            if(cursor!=null){//not pointing at nowhere
                if(cursor.moveToFirst()) {//if cursor at beginning
                    List<Assignment> assignments = new ArrayList<>();


                    do {//initialize cursors for whole db row
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_ID));
                        int c_id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_C_ID));
                        String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_ASSN_TITLE));
                        int grade = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_GRADE));

                        //retrieve all cursor values at row and then store
                        assignments.add(new Assignment(id, c_id, title, grade)); //add to arraylist of courses

                    } while (cursor.moveToNext());

                    return assignments; //return this assignment setting
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null) {//if cursor is also not "nowhere"
                cursor.close();//close cursor

                db.close(); //close db
            }
        }//end finally

        return Collections.emptyList(); //return empty list if all else (or null)
    }//end of getAllAssignments



    /*
    //example: get course by course code condition
    //recall course code is String because =COEN, ELEC...
    public Course getCourseByCode(String courseCode){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();//open database in READ mode
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets a course
            //want column equal to whatever argument will be passed for selection argument(after the =?)
            //create new string array
            //"give all courses where column course code is the value that is passed at "new String[]", or (courseCode)
            cursor = db.query(Config.COURSE_NAME_TABLE,null,Config.COLUMN_COURSE_CODE+" = ?",new String[]{courseCode},null,null,null);
            //this will read courses from the database that meet above condition
            if(cursor!=null){
                if(cursor.moveToFirst()) {//if cursor at beginning
                    int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_COURSE_ID));
                    String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_TITLE));
                    String code = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_CODE));
                    //int avg = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_AVG));

                    return new Course(id, title, code); //return a new instance of course from configured db variables above
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null){//if cursor is also not pointing at "nowhere" in the table
                cursor.close();//close cursor
                db.close(); //close db
            }

        }//end finally
        return null;// give null for example if no such course exists
    }//end of getCourseByCode
    */


    //tested, this works
    public Course getCourseByID(Integer _id){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets a course
            //want column equal to whatever argument will be passed for selection argument(after the =?)
            //create new string array
            //"give all courses where column course code is the value that is passed at "new String[]", or (courseCode)
            cursor = db.query(Config.COURSE_NAME_TABLE,null,Config.COLUMN_COURSE_ID + "= ?",new String[]{String.valueOf(_id)},null,null,null);
            //this will read courses from the database that meet above condition
            if(cursor!=null){
                if(cursor.moveToFirst()) {//if cursor at beginning
                    int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_COURSE_ID));
                    String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_TITLE));
                    String code = cursor.getString(cursor.getColumnIndex(Config.COLUMN_COURSE_CODE));


                    return new Course(id, title, code); //return a new instance of course from configured db variables above
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null){//if cursor is also not pointing at "nowhere" in the table
                cursor.close();//close cursor
                db.close(); //close db
            }

        }//end finally
        return null;// give null for example if no such course exists
    }//end of getCourseByID




    //DELETE COURSE by ID
    public Integer deleteCourseByID(Integer _id){ //read course by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();

        try{//if problem encountered

            //delete entire row
            if(db!=null&&db.isOpen()){
                db.delete(Config.COURSE_NAME_TABLE,Config.COLUMN_COURSE_ID + "= ?",new String[]{String.valueOf(_id)});
                db.delete(Config.ASSN_NAME_TABLE,Config.COLUMN_C_ID + "= ?",new String[]{String.valueOf(_id)});
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(db!=null&&db.isOpen()){//if cursor is also not pointing at "nowhere" in the table
                db.close(); //close db
            }
        }//end finally
        return null;// reach end of function
    }//end of getCourseByID


    //get Assignment by Course ID - carbon copy of getCourseByID
    public List<Assignment> getAssignmentByCourseID(Integer _id){ //read assignment by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{//if problem encountered
            //start cursor then call query
            //gets an assignment
            //want column equal to whatever argument will be passed for selection argument(after the =?)
            //create new string array
            //"give all assignments where column course code is the value that is passed at "new String[]", or (courseCode)
            cursor = db.query(Config.ASSN_NAME_TABLE,null,Config.COLUMN_C_ID + "= ?",new String[]{String.valueOf(_id)},null,null,null);
            //this will read courses from the database that meet above condition
            if(cursor!=null){
                if(cursor.moveToFirst()) {//if cursor at beginning
                    List<Assignment> assignments = new ArrayList<>();
                    do {
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_ID));
                        int c_id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_C_ID));
                        String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_ASSN_TITLE));
                        int grade = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_GRADE));

                        assignments.add(new Assignment(id, c_id, title, grade));
                    }while(cursor.moveToNext());


                    return assignments; //return a new instance of assignments from configured db variables above
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null){//if cursor is also not pointing at "nowhere" in the table
                cursor.close();//close cursor
                db.close(); //close db
            }
        }//end finally
        return Collections.emptyList();// give null for example if no such assignment exists
    }//end of getAssignmentByCourseID

    public Integer getAverageByCourseID(Integer _id){ //read assignment by code (handy for main activity
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;//initialize cursor

        try{
            cursor = db.query(Config.ASSN_NAME_TABLE,null,Config.COLUMN_C_ID + "= ?",new String[]{String.valueOf(_id)},null,null,null);
            //this will read courses from the database that meet above condition
            if(cursor!=null){
                if(cursor.moveToFirst()) {//if cursor at beginning
                    int sum=0;
                    int j=0;
                    do {
                        //int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_ID));
                        //int c_id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_C_ID));
                        //String title = cursor.getString(cursor.getColumnIndex(Config.COLUMN_ASSN_TITLE));
                        int grade = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ASSN_GRADE));

                        sum=sum+grade;
                        j++;
                    }while(cursor.moveToNext());


                    return sum/j; //return sum
                }//end if move to first
            }//end if null cursor


        }//end try
        catch(SQLException e){//assign exception as e
            //catch like in insertCourse
            Log.d(TAG, "SQLite Exeption catch: "+e);
            Toast.makeText(context,"SQLite exception catch"+e,Toast.LENGTH_LONG);

        }//end of catch
        finally{//if all else does not fail
            if(cursor!=null){//if cursor is also not pointing at "nowhere" in the table
                cursor.close();//close cursor
                db.close(); //close db
            }
        }//end finally
        return -1;// otherwise give invalid when end of function reached
    }//end of getAvgByCourseID






    //don't touch this
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //alter database
    }
}//end DatabaseHelper
