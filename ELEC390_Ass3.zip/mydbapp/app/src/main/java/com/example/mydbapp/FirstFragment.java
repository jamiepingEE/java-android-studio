package com.example.mydbapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.mydbapp.DatabaseHelper.DatabaseHelper;

public class FirstFragment extends DialogFragment {

    //popup dialog has title, course fields; and save, cancel buttons
    protected EditText editTextCourseTitle;
    protected EditText editTextCourseCode;
    protected Button saveCourseButton;
    protected Button cancelCourseButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //have to pass down parameter "container"
        View view = inflater.inflate(R.layout.fragment_first,container,false);
        //*:attach to root lets touch events affect background, set to false for now

        //*: findViewById function belongs to View object, "view"
        editTextCourseTitle = view.findViewById(R.id.editTextCourseTitle);
        editTextCourseCode = view.findViewById(R.id.editTextCourseCode);
        saveCourseButton = view.findViewById(R.id.saveCourseButton);
        cancelCourseButton = view.findViewById(R.id.cancelCourseButton);

        //onclick listeners
        saveCourseButton.setOnClickListener(onClickSaveCourse);
        cancelCourseButton.setOnClickListener(onClickCancelCourse);

        //return super.onCreateView(inflater, container, savedInstanceState);
        return view; //return inflater instead
    }

    //"Save" button
    protected Button.OnClickListener onClickSaveCourse = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {

            //get user inputs
            String title = editTextCourseTitle.getText().toString();
            String code = editTextCourseCode.getText().toString();

            DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
            if(title!=null&&code!=null&&!title.isEmpty()&&!code.isEmpty()){ //&& SHORTCIRCUIT
                dbHelper.insertCourse(new Course(title,code));//how to get return value of this?
                ((MainActivity)getActivity()).loadListView();//refresh list
                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
            else{//stop the user dead in their tracks
                Toast.makeText(getActivity(), "Invalid Entry: Empty Field Detected", Toast.LENGTH_SHORT).show();
            }
        }
    };

    //"Cancel" button
    protected Button.OnClickListener onClickCancelCourse = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            Toast.makeText(getActivity(), "NO CHANGES MADE", Toast.LENGTH_SHORT).show();
            getDialog().dismiss();
        }
    };
}
