package com.example.mydbapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mydbapp.DatabaseHelper.DatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    protected ListView coursesListView;
    protected FloatingActionButton courseFAB;
    private DatabaseHelper dbHelper;
    protected TextView seeAvg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //MAIN HEADER
        seeAvg = (TextView) findViewById(R.id.seeAverage);


        //start DataBase listview test run example
        //dbHelper = new DatabaseHelper(this);//construct if object created outside
        //DatabaseHelper dbHelper = new DatabaseHelper(this); //construct
        //dbHelper.insertCourse(new Course("TitleTest","CodeTest")); //put this in fragment

        //ListView
        coursesListView = findViewById(R.id.coursesListView);
        coursesListView.setOnItemClickListener(onClickItems);
        loadListView();


        //floating action button
        courseFAB = findViewById(R.id.addCourseFAB);
        courseFAB.setOnClickListener(onClickCourseFAB);
    }

    //listview refresh code
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){//on return from assignment activity using back or delete button with refresh code

            //want to reload listview from delete button or on return
            loadListView();
            //seeAvg.setText("ListView REFRESHED");
        }
    }

    protected ListView.OnItemClickListener onClickItems = new AdapterView.OnItemClickListener(){

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent(MainActivity.this, AssignmentActivity.class);
            String message = coursesListView.getItemAtPosition(position).toString();//prepare our message using item title string
            intent.putExtra("assn_key", message); //let the assn_key messenger carry our message(item title)
            //String message2 = Long.toString(id);//testing purpose: reveal adapter position or id arguments
            //intent.putExtra("curiosity",message2);//send course ID or position
            //intent.putExtra("curiosity",id);//send ID, long-type
            //intent.putExtra("curiosity",coursesListView.getItemIdAtPosition(position));

            //row ID passer
            Course currentCourse = (Course) parent.getItemAtPosition(position);//create course object from list item
            intent.putExtra("curiosity", String.valueOf(currentCourse.getID()));//send row ID from list item course object


            //REFRESH ON RETURN NO MATTER HOW(e.g.: back button on device or delete button)
            //1 is our refresh code
            startActivityForResult(intent,1); //add code=1 in there for refresh on main start
        }
    };

    protected FloatingActionButton.OnClickListener onClickCourseFAB = new FloatingActionButton.OnClickListener(){

        @Override
        public void onClick(View v) {

            FirstFragment insertCourseFragment = new FirstFragment();//new instance of firstfragment
            insertCourseFragment.show(getSupportFragmentManager(),"InsertCourseFragment");
        }
    };


    protected void loadListView(){//create empty array, fill, connect

        //DatabaseHelper dbHelper = new DatabaseHelper(this); //create DatabaseHelper object
        dbHelper = new DatabaseHelper(this); //create DatabaseHelper object
        List<Course> courses = dbHelper.getAllCourses(); //get from db and store into list


        //1. create empty <String> array
        ArrayList<Course> coursesListText = new ArrayList<>(); //expanding array



            int sum = 0;
            int j=0;
            //2. fill coursesListText array
            for (int i = 0; i < courses.size(); i++) {
                coursesListText.add(courses.get(i));//pump course array
                coursesListText.get(i).setAvg(dbHelper.getAverageByCourseID(coursesListText.get(i).getID()));//meanwhile, set average

                if(coursesListText.get(i).getAvg()!=-1) {//prevent bad averaging
                    sum += coursesListText.get(i).getAvg();//meanwhile calculate overall average too
                    j++;
                }
            }//end for loop
        if(j!=0) {//prevent division by 0
            seeAvg.setText("OVERALL AVERAGE = " + Integer.toString(sum/j));
        }
        else{
            seeAvg.setText("OVERALL AVERAGE = N/A");
        }


        //3. link adapter to get array2listview
        ArrayAdapter<Course> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, coursesListText);//arraylist to adapter
        coursesListView.setAdapter(arrayAdapter);//connect our array adapter to our ListView




    }//end loadListView

}