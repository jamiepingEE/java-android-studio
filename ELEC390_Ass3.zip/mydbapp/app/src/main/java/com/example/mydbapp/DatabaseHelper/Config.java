package com.example.mydbapp.DatabaseHelper;

public class Config {//db config
    public final static String DATABASE_NAME = "courses-db";
    public static final int DATABASE_VERSION = 1;

    public static final String COURSE_NAME_TABLE = "course";

    //3 columns
    public static final String COLUMN_COURSE_ID = "_id"; //number 1,2,3
    public static final String COLUMN_COURSE_TITLE = "title"; //MINICAP, INTRODUCTION TO...
    public static final String COLUMN_COURSE_CODE = "code"; //COEN/ELEC etc...


    public static final String ASSN_NAME_TABLE = "assignment";

    //3 columns
    public static final String COLUMN_ASSN_ID = "g_id"; //number 1,2,3
    public static final String COLUMN_ASSN_TITLE = "gtitle"; //aSsn...
    public static final String COLUMN_ASSN_GRADE = "grade"; //number grade in string
    public static final String COLUMN_C_ID = "c_id"; //associated course ID


}
