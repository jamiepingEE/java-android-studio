package com.example.mydbapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mydbapp.DatabaseHelper.DatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class AssignmentActivity extends AppCompatActivity {

    //UI objects
    protected FloatingActionButton assnFAB;
    protected TextView assnHeader;
    protected Button deleteButton;
    protected ListView assnsListView;
    protected DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment);

        //Receive inbound message from main activity
        Intent intent = getIntent();//coming from item click with item title string and refresh code=1
        String assn_key = intent.getStringExtra("assn_key"); //convert title of item to string
        String reveal = intent.getStringExtra("curiosity"); //get int position or long id
        idSet(reveal);//takes in String
        //long supposed_ID = intent.getLongExtra("curiosity",-1);
        //int cid= (int) supposed_ID;


        //TextView
        assnHeader = (TextView) findViewById(R.id.assnActivityHeader);
        assnHeader.setText(assn_key.substring(0,assn_key.length()-19)); //use as this received message as activity's header
        //assnHeader.setText(reveal); //test purpose: reveal in header of Assignment Activity


        //floating action button
        assnFAB = findViewById(R.id.assignmentFAB);
        assnFAB.setOnClickListener(onClickAssnFAB);

        //delete button
        deleteButton = (Button) findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(setOnClickDelete);

        assnsListView = findViewById(R.id.assnsListView);
        loadAssnsListView(); //see all assignments here
    }

    private Integer IDget;//globalize course ID
    public void idSet(String input){
        this.IDget = Integer.valueOf(input);
    }
    public Integer idGet(){return IDget;}

    protected FloatingActionButton.OnClickListener onClickAssnFAB = new FloatingActionButton.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent = getIntent();
            String reveal = intent.getStringExtra("curiosity");
            Bundle bundle = new Bundle();
            bundle.putString("dearFragment",reveal); //String-type
            SecondFragment insertAssnFragment = new SecondFragment();//new instance of sec fragment
            insertAssnFragment.show(getSupportFragmentManager(),"InsertAssnFragment");
            insertAssnFragment.setArguments(bundle);//stuff key inside
        }
    };


    protected void loadAssnsListView(){//carbon copy of loadCoursesListView


        dbHelper = new DatabaseHelper(this); //create DatabaseHelper object
        //only want assignments with C_ID
        List<Assignment> assignments = dbHelper.getAssignmentByCourseID(idGet()); //get from db and store into list

        //1. create empty <String> array
        ArrayList<Assignment> assignmentsListText = new ArrayList<>(); //expanding array

        //2. fill assignmentsListText array
        for(int i = 0; i<assignments.size();i++){

            assignmentsListText.add(assignments.get(i));//pump this list
        }//end for loop


        ArrayAdapter<Assignment> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, assignmentsListText);//arraylist to adapter
        assnsListView.setAdapter(arrayAdapter);//connect our array adapter to our ListView
    }//end loadAssignmentsList

    //delete button
    protected Button.OnClickListener setOnClickDelete = new Button.OnClickListener(){
        @Override
        public void onClick(View v) {

            deleteCourse();
            finish();//return to main activity
        }

    };

    public void deleteCourse(){//delete course and associated assignments by course ID

        //the big annoying challenge
        dbHelper = new DatabaseHelper(this); //create DatabaseHelper object
        dbHelper.deleteCourseByID(idGet());
    };


}//end Assignment Activity