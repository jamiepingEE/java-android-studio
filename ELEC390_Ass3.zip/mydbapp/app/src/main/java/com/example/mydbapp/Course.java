package com.example.mydbapp;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private Integer ID; //Integer incr.
    private String Title; //Fundamentals of...
    private String Code; //COEN/ELEC
    private int Avg=-1;

    @NonNull
    @Override
    public String toString() {//override for listview display
        //return super.toString();
        //return getID() + " " + getTitle() + "\n" + getCode();

        if(Avg!=-1) {//handle -1
            return getID() + " " + getTitle() + "\n" + getCode() + "\n" + "\n" + "Course average: " + getAvg();
        }
        else{
            return getID() + " " + getTitle() + "\n" + getCode() + "\n" + "\n" + "Course average: N/A";
        }

    }


    public Integer getAvg() {//get course avg
        return Avg;
    }

    public void setAvg(int avg) {
        Avg = avg;
    }

    //constructor from generate Constructor
    public Course(Integer ID, String title, String code) {//for listview
        this.ID = ID;
        Title = title;
        Code = code;
    }

    //title and code only
    public Course(String title, String code) {//need this for activity 2 or fragment
        Title = title;
        Code = code;
    }

    //getters
    public Integer getID() {
        return ID;
    }

    public String getTitle() {
        return Title;
    }

    public String getCode() {
        return Code;
    }

    //setters (shortcut from right click>generate>getters and setters
    public void setID(Integer ID) {
        this.ID = ID;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setCode(String code) {
        Code = code;
    }


}//class Course end
