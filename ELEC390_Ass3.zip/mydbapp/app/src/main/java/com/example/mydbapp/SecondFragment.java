package com.example.mydbapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.mydbapp.DatabaseHelper.DatabaseHelper;

public class SecondFragment extends DialogFragment {

    protected EditText editAssTitle;
    protected EditText editAssGrade;
    protected Button cancelAss;
    protected Button saveAss;
    protected TextView fragmentHeader;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.secondfragment, container,false);

        //link UI objects by ID
        editAssTitle = view.findViewById(R.id.editAssignmentTitle);
        editAssGrade = view.findViewById(R.id.editAssignmentGrade);
        saveAss = view.findViewById(R.id.assignmentSaveButton);
        cancelAss = view.findViewById(R.id.assignmentCancelButton);

        //listeners
        saveAss.setOnClickListener(onClickSave);
        cancelAss.setOnClickListener(onClickCancel);

        //pass data from main>list item>assignmentactivity>FAB>fragment
        Bundle bundle = this.getArguments();//receive
        String idPass = bundle.getString("dearFragment"); //read message
        idSet(idPass); //set global String variable, or announce message

        //course ID logger
        fragmentHeader = view.findViewById(R.id.fragmentHeader);
        fragmentHeader.setText("course ID value passed: "+ idPass);



        return view;
    } //end onCreate

    String IDget;
    public void idSet(String input){
        this.IDget = input;
    }
    public String idGet(){return IDget;}


    //save button functionality
    protected Button.OnClickListener onClickSave = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {

            //get user inputs
            String title = editAssTitle.getText().toString();
            String grade = editAssGrade.getText().toString();
            String passedID = idGet();//write message


            //the big challenge
            DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
            if(title!=null&&grade!=null&&!title.isEmpty()&&!grade.isEmpty()&&Integer.parseInt(grade)<101){ //&& SHORTCIRCUIT
                dbHelper.insertAssignment(new Assignment(Integer.parseInt(passedID),title,Integer.parseInt(grade)));//buggy
                ((AssignmentActivity)getActivity()).loadAssnsListView();//refresh list
                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
            else{//stop the user dead in their tracks: DON'T PROCEED
                Toast.makeText(getActivity(), "Invalid Entry", Toast.LENGTH_SHORT).show();
            }

        }//end onClick override
    }; //end save button

    //cancel button
    protected Button.OnClickListener onClickCancel = new Button.OnClickListener(){
        @Override
        public void onClick(View v) {//harmless
            Toast.makeText(getActivity(), "NO CHANGES MADE", Toast.LENGTH_SHORT).show();
            getDialog().dismiss();
        }
    }; //end cancel button

}
