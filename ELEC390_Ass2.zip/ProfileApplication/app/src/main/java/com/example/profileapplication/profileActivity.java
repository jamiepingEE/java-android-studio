package com.example.profileapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class profileActivity extends AppCompatActivity {

    protected EditText nameEdit;
    protected EditText ageEdit;
    protected EditText studentidEdit;
    protected Button saveButton;
    //initialize classes
    protected SharedPreferenceHelper sharedPreferenceHelper; //pre-made class

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        receiveIntent();
        sharedPreferenceHelper = new SharedPreferenceHelper(this);


        setProfileUI();
    }

    void receiveIntent(){
        Intent intent = getIntent();
        String profileKey = intent.getStringExtra(getString(R.string.profile_key));
    }
    //save button

    void setProfileUI(){
        nameEdit = findViewById(R.id.nameField);
        nameEdit.setText(sharedPreferenceHelper.getProfileName());

        ageEdit = findViewById(R.id.ageField);
        ageEdit.setText(sharedPreferenceHelper.getProfileAge());//setText only takes in strings-must convert 0 to null

        studentidEdit = findViewById(R.id.studentidField);
        studentidEdit.setText( sharedPreferenceHelper.getProfileID() );


        nameEdit.setFocusableInTouchMode(false); //we know this works: don't change this
        ageEdit.setFocusableInTouchMode(false);
        studentidEdit.setFocusableInTouchMode(false);

        saveButton = findViewById(R.id.saveButton_id);
        saveButton.setOnClickListener(onClickSaveButton);
    }//end setProfileUI


    private Button.OnClickListener onClickSaveButton = new Button.OnClickListener(){

        @Override
        public void onClick(View v) {
            //save in profile class
            String name = nameEdit.getText().toString();
            String age = ageEdit.getText().toString(); //user input buffer to int
            String studentID=studentidEdit.getText().toString();
            sharedPreferenceHelper.saveProfileName(name);

            if(age!=null&&!age.isEmpty()&&Integer.parseInt(age)>17){//if any of these conditions
                sharedPreferenceHelper.saveProfileAge(age);
                sharedPreferenceHelper.saveProfileID(studentID);
            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(), "invalid entry", Toast.LENGTH_LONG);
                toast.show();
            }


            //prevent editing
            nameEdit.setFocusableInTouchMode(false); //we know this works: don't change this
            ageEdit.setFocusableInTouchMode(false);
            studentidEdit.setFocusableInTouchMode(false);

            Toast toast = Toast.makeText(getApplicationContext(),"saved!",Toast.LENGTH_LONG);
            toast.show();
        }//end onClick
    };//end onClickSaveButton


    //edit button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        //put this somewhere
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            //allows editing: this works do not change
            nameEdit.setFocusableInTouchMode(true);
            ageEdit.setFocusableInTouchMode(true);
            studentidEdit.setFocusableInTouchMode(true);
            Toast toast = Toast.makeText(getApplicationContext(),"Fields editable",Toast.LENGTH_LONG);
            toast.show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}//end profileActivity