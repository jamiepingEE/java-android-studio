package com.example.profileapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    //initialize classes
    protected SharedPreferenceHelper sharedPreferenceHelper; //pre-made class
    protected Button profileButton; //nameless button
    //protected static final String TAG="OnStart";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //load custom shared preferences
        //initialize/set context for class/construct

        //profileButton.setOnClickListener(new View.OnClickListener() {

        setupUI();
    }

    protected void setupUI() {
        profileButton = (Button) findViewById(R.id.profileButton_id);
        profileButton.setOnClickListener(onClickProfileButton);
    }

    private Button.OnClickListener onClickProfileButton = new Button.OnClickListener() {
        @Override
        public void onClick(View view) {
            goToProfileActivity();
        }
    };//end onClickListener method override

    @Override
    protected void onStart() {
        super.onStart();
        //this is already in the profile class
        //SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.ProfileFileName), Context.MODE_PRIVATE);
        //this is a guideline to initialize as null
        //String buttonName = sharedPreferences.getString(getString(button_name),null);

        sharedPreferenceHelper = new SharedPreferenceHelper(this);
        //starts off =null inside the class anyway
        //buttonName will be "gotten" as null or user-set

        String buttonName = sharedPreferenceHelper.getProfileName(); //get it from the class instead

        //Log.d(TAG,"button name is: "+button_name);
        if (buttonName != null&&!buttonName.isEmpty()) {//if any conditions fail, shortcircuit to force skip
            profileButton.setText(buttonName); //stay in welcome screen
        } else {
            goToProfileActivity(); //force skip welcome screen

        }

    }//end onStart() method override


    protected void goToProfileActivity() {
        Intent intent = new Intent(this, profileActivity.class);
        intent.putExtra(getString(R.string.profile_key), "profileKey");
        startActivity(intent);
    }//end goToProfileActivity()

}//end MainActivity
