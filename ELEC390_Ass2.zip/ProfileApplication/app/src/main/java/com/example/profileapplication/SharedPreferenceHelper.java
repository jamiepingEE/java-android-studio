package com.example.profileapplication;

import android.content.Context;
import android.content.SharedPreferences;

//import static com.example.profileapplication.R.string.ProfilePreferenceName;

public class SharedPreferenceHelper {
    private SharedPreferences sharedPreferences;

    public SharedPreferenceHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(context.getString(R.string.ProfilePreferenceName), Context.MODE_PRIVATE);
    }


    //profile name section
    public void saveProfileName(String name) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("saved_name", name);
        editor.apply();
    }

    public String getProfileName() {
        return sharedPreferences.getString("saved_name", null);
        //this should be the id of field title?
    }

    //profile age section
    public void saveProfileAge(String age) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("saved_age", age);
        editor.apply();
    }

    public String getProfileAge() {
        return sharedPreferences.getString("saved_age", null);
    }


    //profile student ID section
    public void saveProfileID(String studentID) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("saved_studentID", studentID);
        editor.apply();
    }

    public String getProfileID() {
        return sharedPreferences.getString("saved_studentID", null);
    }

}//SharedPreferenceHelper() end