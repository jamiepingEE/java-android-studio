package com.example.driverlib;

import java.util.ArrayList;
import java.util.Random;

public class Driver {
    public static ArrayList<String> tempArray = new ArrayList<String>();

    //this code will store courses, variables: avg, and can then be directly stored into tempArray
    public static void main(String[] a) {
        //keep these two lines for app
        Random rnd = new Random();  //keep this
        int courseNo = rnd.nextInt(5); //i: 5 then randomize course count 0-4
        ArrayList<Course> courses = new ArrayList<Course>(); //create course list

        for (int i = 0; i < courseNo; i++) {
            courses.add(Course.generateRandomCourse()); //fill courses array list
        }

        //listview
        if(courses.size()==0){
            tempArray.add("no courses to show");
        }
        else {
            //test input into getLetter converter
            for(int i=0; i<courses.size(); i++) {
                //System.out.println(courses.get(i).getCourseTitle() + " avg: " + avg(courses.get(i).getAssignments()) );

                if(courses.get(i).getAssignments().size()==0){
                    tempArray.add(courses.get(i).getCourseTitle() + " avg: - "); //take int, return string
                    tempArray.add("no assignments to show");
                }
                else {
                    tempArray.add(courses.get(i).getCourseTitle() + " avg: " + avg(courses.get(i).getAssignments()) ); //take int, return string
                    for (int j = 0; j < courses.get(i).getAssignments().size(); j++) {
                        //System.out.println( courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + courses.get(i).getAssignments().get(j).getAssignmentGrade());
                        tempArray.add(courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + courses.get(i).getAssignments().get(j).getAssignmentGrade() ); //load assignment
                    }
                }
            }
        } //end for default tempArray
/*
        if(courses.size()==0){
            tempArray.add("no courses to show");
        }
        else {
        //test input into getLetter converter
        for(int i=0; i<courses.size(); i++) {
            //System.out.println(courses.get(i).getCourseTitle() + " avg: " + avg(courses.get(i).getAssignments()) );

                if(courses.get(i).getAssignments().size()==0){
                    tempArray.add(courses.get(i).getCourseTitle() + " avg: - "); //take int, return string
                    tempArray.add("no assignments to show");
                }
                else {
                    tempArray.add(courses.get(i).getCourseTitle() + " avg: " + getLetter(avg(courses.get(i).getAssignments())) ); //take int, return string
                    for (int j = 0; j < courses.get(i).getAssignments().size(); j++) {
                        //System.out.println( courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + courses.get(i).getAssignments().get(j).getAssignmentGrade());
                        tempArray.add(courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + getLetter(courses.get(i).getAssignments().get(j).getAssignmentGrade()) ); //load assignment
                    }
                }
            }
        } //end for letter tempArray
*/
        for(int i=0; i<tempArray.size(); i++) {
            System.out.println(tempArray.get(i));
        }



    } //end main

    static public int avg(ArrayList<Assignment> assns){
        int result = 0;
        int sum = 0;
        for (int i = 0; i < assns.size(); i++) {
            sum = sum + assns.get(i).getAssignmentGrade();
        }
        result = sum / assns.size();
        return result;
    }

    //getLetter(int value);
    static public String getLetter(int value) {
        String letterGrade;
        int c = value / 10;
//case is like else if
        switch (c) {
            // If 90 or greater A
            case 9:
                letterGrade = "A";
                break;
            // If 80 or greater B
            case 8:
                letterGrade = "B";
                break;
            // If 70 or greater C
            case 7:
                letterGrade = "C";
                break;
            // If 60 or greater D
            case 6:
                letterGrade = "D";
                break;
            // 59 or below F
            default:
                letterGrade = "F";
        }
        return letterGrade;
    }

} //end driver
        /*
        String letterGrade;

        //fill course list
        for(int j=0; j<courseno; j++) {//repeat the following

            Course course = Course.generateRandomCourse(); //create course
            courses.add(course); //add to courses list
            ArrayList<Assignment> assignments = course.getAssignments();

            //get course average based on assignments arraylist from inside of course

                disp= String.valueOf(avg); //store in disp

                //get letter grade
                //public getLetter (int c){
                string letterGrade;
                c = avg /10;
//case is like else if
                switch (c) {
                    // If 90 or greater A
                    case 9:
                        letterGrade = "A";
                        break;
                    // If 80 or greater B
                    case 8:
                        letterGrade = "B";
                        break;
                    // If 70 or greater C
                    case 7:
                        letterGrade = "C";
                        break;
                    // If 60 or greater D
                    case 6:
                        letterGrade = "D";
                        break;
                    // 59 or below F
                    default:
                        letterGrade = "F";
                    return letterGrade;
                }
             }

                //ready variables: int avg, String disp, String lettergrade0,

                courseLetArrStr.add(courses.get(j).getCourseTitle() + " " + letterGrade0 );
                System.out.println(courseLetArrStr.get(j));
                //           System.out.println( courses.get(j).getCourseTitle() + " " + disp ); //output string to listview instead and force change font
            }
            courseNumArrStr.add(courses.get(j).getCourseTitle() + " " + disp );
            System.out.println(courseNumArrStr.get(j));





            for (int i = 0; i < assignments.size(); i++) {
                System.out.println(assignments.get(i).getAssignmentTitle() + " " + assignments.get(i).getAssignmentGrade()); //should output string to listview instead

                //get letter grade
                int b = assignments.get(i).getAssignmentGrade() /10;
//case is like else if
                    switch (b) {
                        // If 90 or greater A
                        case 9:
                            letterGrade = "A";
                        break;
                        // If 80 or greater B
                        case 8:
                            letterGrade = "B";
                        break;
                        // If 70 or greater C
                        case 7:
                            letterGrade = "C";
                        break;
                        // If 60 or greater D
                        case 6:
                            letterGrade = "D";
                        break;
                        // 59 or below F
                        default:
                            letterGrade = "F";
                    }

                courseArrStr.add(assignments.get(i).getAssignmentTitle() + " " + letterGrade ); //store or display subtitles
                System.out.println(courseArrStr.get(i));
            }
        }
    }
}
//create course ID and generate random# of assignments, fill assignment arraylist
//show assignment title assignment grade i-times
//loop this all j-times

//To do: generate two arrays in proper order
//output in listview in that order

//available function members from:
// Course.java: String getCourseTitle() , ArrayList<Assignment> getAssignments() . Course generateRandomCourse()
// Assignment.java: Assignment generateRandomAssignment() , String getAssignmentTitle() , int getAssignmentGrade()


         */