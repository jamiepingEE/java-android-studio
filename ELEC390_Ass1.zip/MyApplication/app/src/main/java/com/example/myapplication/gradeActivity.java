package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Random;

public class gradeActivity extends AppCompatActivity {

    //protected static final String TAG="gradeActivity";

    protected Button back_button_id = null; //import Button class from android.widget lib
    public ArrayList<Course> courses = new ArrayList<Course>(); //create course list
    public ArrayList<String> tempArray = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        //Log.d(TAG,"onCreate is happening");

        Intent intent = getIntent(); //receive intent from MainActivity
        String list_key = intent.getStringExtra(getString(R.string.list_key_id)); //receive intent key from mainActivity


        gradeobjectUI(); // gradeActivity UI layer
    }

    protected void gradeobjectUI(){ //define gradeobjectUI function here
        //contains
        //course list randomizer
        //toggle off -> (flags: default or getLetter)
        //back button

        //ListView configuration
        ListView listView = (ListView) findViewById(R.id.listview_id);
        getCourses(); //randomize list
        defaultList(); //load default course list without letter grade
        ArrayAdapter<String> adaptstr = new ArrayAdapter<String>(gradeActivity.this, android.R.layout.simple_list_item_1, tempArray); //converts all to string anyway
        //adaptstr.clear();
        listView.setAdapter(adaptstr);
        adaptstr.notifyDataSetChanged();

        //toggle button here
        ToggleButton toggleButton = (ToggleButton) findViewById(R.id.togglebutton_id);
        toggleButton.setOnCheckedChangeListener(toggleFuncs); //call toggleFuncs

        //"return to previous" button instantiation
        back_button_id = (Button) findViewById(R.id.back_button_id); //instantiate Button member
        //instantiate return type Button, pass R-class-to.id.idname to findviewbyid function
        back_button_id.setOnClickListener(OnClickMainActivity); //call function onClickListener()


    }//end gradeobjectUI()



    //constructors
    //toggle button
    private CompoundButton.OnCheckedChangeListener toggleFuncs = new CompoundButton.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked){
                ListView listView = (ListView) findViewById(R.id.listview_id);
                //receive courses array -> A: -> tempArray -> listview
                //listView.setAdapter(null);
                letterList();
                ArrayAdapter<String> adaptstr = new ArrayAdapter<String>(gradeActivity.this, android.R.layout.simple_list_item_1, tempArray); //converts all to string anyway
                listView.setAdapter(adaptstr);
                adaptstr.notifyDataSetChanged();

            }
            else{
                //receive courses array -> temparray -> listview
                //listView.setAdapter(null);
                ListView listView = (ListView) findViewById(R.id.listview_id);
                defaultList();
                ArrayAdapter<String> adaptstr = new ArrayAdapter<String>(gradeActivity.this, android.R.layout.simple_list_item_1, tempArray); //converts all to string anyway
                listView.setAdapter(adaptstr);
                adaptstr.notifyDataSetChanged();

            }
        }
    };

    //back button instantiation and prototype
    private Button.OnClickListener OnClickMainActivity = new Button.OnClickListener(){

        //define sendBack(); function
        private void sendBack(){
            Intent backintent = new Intent(gradeActivity.this,MainActivity.class);
            startActivity(backintent);
            finish();
        }

        //implement back button
        @Override
        public void onClick(View view) {
            sendBack(); //go to to MainActivity
        }
    }; //semicolon after class declaration

    public void getCourses(){
        //courses.clear();
        Random rnd = new Random();  //keep this
        int courseNo = rnd.nextInt(5); //i: 5 then randomize course count 0-4


        for (int i = 0; i < courseNo; i++) {
            courses.add(Course.generateRandomCourse()); //fill courses array list
        }
    }

    public void defaultList(){
        tempArray.clear();
        if(courses.size()==0){
            tempArray.add("no courses to show");
        }
        else {
            //test input into getLetter converter
            for(int i=0; i<courses.size(); i++) {
                //System.out.println(courses.get(i).getCourseTitle() + " avg: " + avg(courses.get(i).getAssignments()) );

                if(courses.get(i).getAssignments().size()==0){
                    tempArray.add(courses.get(i).getCourseTitle() + "      avg: - "); //take int, return string
                    tempArray.add("no assignments to show");
                }
                else {
                    tempArray.add(courses.get(i).getCourseTitle() + "      avg: " + avg(courses.get(i).getAssignments()) ); //take int, return string
                    for (int j = 0; j < courses.get(i).getAssignments().size(); j++) {
                        //System.out.println( courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + courses.get(i).getAssignments().get(j).getAssignmentGrade());
                        tempArray.add(courses.get(i).getAssignments().get(j).getAssignmentTitle() + "     " + courses.get(i).getAssignments().get(j).getAssignmentGrade() ); //load assignment
                    }
                }
            }
        } //end for default tempArray
    }

    public void letterList(){
        tempArray.clear();
        if(courses.size()==0){
            tempArray.add("no courses to show");
        }
        else {
            //test input into getLetter converter
            for(int i=0; i<courses.size(); i++) {
                //System.out.println(courses.get(i).getCourseTitle() + " avg: " + avg(courses.get(i).getAssignments()) );

                if(courses.get(i).getAssignments().size()==0){
                    tempArray.add(courses.get(i).getCourseTitle() + "      avg: - "); //take int, return string
                    tempArray.add("no assignments to show");
                }
                else {
                    tempArray.add(courses.get(i).getCourseTitle() + "      avg: " + getLetter(avg(courses.get(i).getAssignments())) ); //take int, return string
                    for (int j = 0; j < courses.get(i).getAssignments().size(); j++) {
                        //System.out.println( courses.get(i).getAssignments().get(j).getAssignmentTitle() + " " + courses.get(i).getAssignments().get(j).getAssignmentGrade());
                        tempArray.add(courses.get(i).getAssignments().get(j).getAssignmentTitle() + "     " + getLetter(courses.get(i).getAssignments().get(j).getAssignmentGrade()) ); //load assignment
                    }
                }
            }
        } //end for letter tempArray
    }

    static public int avg(ArrayList<Assignment> assns){
        int result = 0;
        int sum = 0;
        for (int i = 0; i < assns.size(); i++) {
            sum = sum + assns.get(i).getAssignmentGrade();
        }
        result = sum / assns.size();
        return result;
    }//end avg()

    static public String getLetter(int value) {
        String letterGrade;
        int c = value / 10;
//case is like else if
        switch (c) {
            // If 90 or greater A
            case 9:
                letterGrade = "A";
                break;
            // If 80 or greater B
            case 8:
                letterGrade = "B";
                break;
            // If 70 or greater C
            case 7:
                letterGrade = "C";
                break;
            // If 60 or greater D
            case 6:
                letterGrade = "D";
                break;
            // 59 or below F
            default:
                letterGrade = "F";
        }
        return letterGrade;

    }//end getLetter()

}//end gradeActivity main