package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button; //the Button class was imported
import android.widget.TextView;

//AppCompatActivity has predefined structures
//extends=inherit from android library class, AppCompatActivity
public class MainActivity extends AppCompatActivity {

    protected static final String TAG="MainActivity";//event class name as string to be output in console
    //predefine the java string TAG for event below
    //test device specs: Nexus 5
    protected Button View_My_Grade_Buttonid = null; //import Button class from android.widget lib
    protected TextView View_Grade_Screenid; //Front page header text

    @Override
    protected void onCreate(Bundle savedInstanceState) { //onCreate function exists by default upon
        //new "MainActivity", onCreate is also predefined by AppCompatActivity
        super.onCreate(savedInstanceState); //overrides by assigning class "super", instance definition
        setContentView(R.layout.activity_main); //content layout implemented by default on activity creation
        //log.d(TAG,"message to be output in android console");
        Log.d(TAG,"onCreate is happening"); //define TAG as class name, msg:event indicator
        objectUI(); //call front page UI layer
    }

    protected void objectUI(){ //define object
        View_My_Grade_Buttonid = (Button) findViewById(R.id.View_My_Grade_Buttonid); //instantiate Button member
        View_Grade_Screenid = (TextView) findViewById(R.id.View_Grade_Screenid);
        //instantiate return type TextView, pass R class.id.idname to findviewbyid function
        View_My_Grade_Buttonid.setOnClickListener(OnClickgradeActivity); //call function onClickListener()
    }
    //AppCompatActivity sequence is onStart(), onResume(), onPause(), onStop(), onDestroy()
    //private variables and constructor
    private Button.OnClickListener OnClickgradeActivity = new Button.OnClickListener(){
        //constructor for Button.OnClickListener
        //private class.memberfunction object = instantiate with dynamic storage new object

        //define sendMessage();
        private void sendMessage(){
            Intent intent = new Intent(MainActivity.this,gradeActivity.class);
            intent.putExtra(getString(R.string.list_key_id),"list_key");
            startActivity(intent); //call intent
            /*
            switch(expression) {
                case x:
                    // code block
                    break;
                case y:
                    // code block
                    break;
                default:
                    // code block

            }*/
        }

        //implement from line 40
        @Override
        public void onClick(View view) {
            //do something when user hits View My Grade
            //want to go to gradeActivity instance
            //example: change View_Grade_Screenid display message
            //View_Grade_Screenid.setText("new text appeared");
            sendMessage(); //go to gradeActivity page
        }
    }; //semicolon after class definition
}

